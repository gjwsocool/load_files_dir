#include "CWorker.h"

CWorker::CWorker()
{
}

CWorker::~CWorker()
{
}

// ofstream& operator<<(ofstream& ofs, const CWorker* worker)
// {
//     ofs<<worker->_id<<" " << worker->_name << " " << worker->_level<<endl;
//     return ofs;
// }